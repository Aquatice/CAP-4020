{--
Francisco Samuel Rios
F3004898
COP 4020
September 12, 2015
--}


module Average3 where

average3 :: (Double,Double,Double) -> Double

average3 (x, y, z) = (x + y + z) / 3
